-- Linux audio player wrapper with volume support.

local function command_exists(cmd)
    local ok = os.execute("command -v " .. cmd .. " >/dev/null 2>&1")
    return ok == true or ok == 0
end

-- Each entry knows how to build its command line given a volume (0-100).
local candidates = {
    {
        bin = "paplay",
        build = function(path, vol)
            -- paplay --volume range: 0 (mute) .. 65536 (100%)
            local v = math.floor((vol / 100) * 65536)
            return string.format("paplay --volume=%d %s", v, path)
        end,
    },
    {
        bin = "pw-play",
        build = function(path, vol)
            -- pw-play --volume range: 0.0 .. 1.0 (linear)
            local v = vol / 100
            return string.format("pw-play --volume=%.3f %s", v, path)
        end,
    },
    {
        bin = "ffplay",
        build = function(path, vol)
            -- ffplay -volume range: 0 .. 100
            return string.format("ffplay -nodisp -autoexit -loglevel quiet -volume %d %s",
                                 math.floor(vol), path)
        end,
    },
    {
        bin = "aplay",
        build = function(path, vol)
            -- aplay has no built-in volume; ignore it.
            return string.format("aplay -q %s", path)
        end,
    },
}

local chosen = nil
for _, c in ipairs(candidates) do
    if command_exists(c.bin) then
        chosen = c
        break
    end
end

local function shell_escape(path)
    return "'" .. path:gsub("'", "'\\''") .. "'"
end

local function playsound(filepath, volume)
    if not chosen then
        print("[playsound] No audio player found (paplay, pw-play, ffplay, aplay).")
        return
    end
    if not filepath or filepath == "" then
        return
    end
    volume = tonumber(volume) or 100
    if volume < 0 then volume = 0 end
    if volume > 100 then volume = 100 end

    local cmd = chosen.build(shell_escape(filepath), volume) .. " >/dev/null 2>&1 &"
    os.execute(cmd)
end

local function player_name()
    return chosen and chosen.bin or "none"
end

return {
    playsound  = playsound,
    player_name = player_name,
}
