local snd = require('playsound')

o = obslua

-- Defaults (you can keep just two WAVs and point all four at them initially).
local DEFAULT_START = script_path() .. "defaultstart.wav"
local DEFAULT_STOP  = script_path() .. "defaultstop.wav"

-- Current settings (populated by script_update).
local cfg = {
    rec_start_path    = DEFAULT_START,
    rec_stop_path     = DEFAULT_STOP,
    stream_start_path = DEFAULT_START,
    stream_stop_path  = DEFAULT_STOP,
    volume            = 100,
}

function script_description()
    return [[<b>Recording / Streaming Audio Notifications</b><br/>
Plays a sound when recording or streaming starts or stops.<br/>
Supports separate sounds per event, a master volume, and test buttons.<br/><br/>
<i>Linux version — uses paplay / pw-play / ffplay / aplay.</i>]]
end

function script_load()
    o.obs_frontend_add_event_callback(obs_frontend_callback)
end

function script_unload()
end

function obs_frontend_callback(event, private_data)
    if event == o.OBS_FRONTEND_EVENT_RECORDING_STARTED then
        snd.playsound(cfg.rec_start_path, cfg.volume)
    elseif event == o.OBS_FRONTEND_EVENT_RECORDING_STOPPED then
        snd.playsound(cfg.rec_stop_path, cfg.volume)
    elseif event == o.OBS_FRONTEND_EVENT_STREAMING_STARTED then
        snd.playsound(cfg.stream_start_path, cfg.volume)
    elseif event == o.OBS_FRONTEND_EVENT_STREAMING_STOPPED then
        snd.playsound(cfg.stream_stop_path, cfg.volume)
    end
end

-- ---------- Test button callbacks ----------

local function test_rec_start()    snd.playsound(cfg.rec_start_path,    cfg.volume) end
local function test_rec_stop()     snd.playsound(cfg.rec_stop_path,     cfg.volume) end
local function test_stream_start() snd.playsound(cfg.stream_start_path, cfg.volume) end
local function test_stream_stop()  snd.playsound(cfg.stream_stop_path,  cfg.volume) end

-- ---------- Properties UI ----------

function script_properties()
    local AUDIO_FILTER = "Audio files (*.wav *.ogg *.flac *.mp3)"
    local p = o.obs_properties_create()

    -- Volume slider (0-100, integer steps)
    o.obs_properties_add_int_slider(p, "volume", "Volume (%)", 0, 100, 1)

    -- Recording group
    local rec_group = o.obs_properties_create()
    o.obs_properties_add_path(rec_group, "rec_start_path",
        "Recording start sound", o.OBS_PATH_FILE, AUDIO_FILTER, nil)
    o.obs_properties_add_button(rec_group, "test_rec_start",
        "▶ Test recording start", test_rec_start)
    o.obs_properties_add_path(rec_group, "rec_stop_path",
        "Recording stop sound", o.OBS_PATH_FILE, AUDIO_FILTER, nil)
    o.obs_properties_add_button(rec_group, "test_rec_stop",
        "▶ Test recording stop", test_rec_stop)
    o.obs_properties_add_group(p, "rec_group", "Recording",
        o.OBS_GROUP_NORMAL, rec_group)

    -- Streaming group
    local stream_group = o.obs_properties_create()
    o.obs_properties_add_path(stream_group, "stream_start_path",
        "Streaming start sound", o.OBS_PATH_FILE, AUDIO_FILTER, nil)
    o.obs_properties_add_button(stream_group, "test_stream_start",
        "▶ Test streaming start", test_stream_start)
    o.obs_properties_add_path(stream_group, "stream_stop_path",
        "Streaming stop sound", o.OBS_PATH_FILE, AUDIO_FILTER, nil)
    o.obs_properties_add_button(stream_group, "test_stream_stop",
        "▶ Test streaming stop", test_stream_stop)
    o.obs_properties_add_group(p, "stream_group", "Streaming",
        o.OBS_GROUP_NORMAL, stream_group)

    -- Info line showing the detected backend
    o.obs_properties_add_text(p, "_info",
        "Audio backend in use: " .. snd.player_name(),
        o.OBS_TEXT_INFO)

    return p
end

function script_defaults(s)
    o.obs_data_set_default_string(s, "rec_start_path",    DEFAULT_START)
    o.obs_data_set_default_string(s, "rec_stop_path",     DEFAULT_STOP)
    o.obs_data_set_default_string(s, "stream_start_path", DEFAULT_START)
    o.obs_data_set_default_string(s, "stream_stop_path",  DEFAULT_STOP)
    o.obs_data_set_default_int(s,    "volume",            100)
end

function script_update(s)
    cfg.rec_start_path    = o.obs_data_get_string(s, "rec_start_path")
    cfg.rec_stop_path     = o.obs_data_get_string(s, "rec_stop_path")
    cfg.stream_start_path = o.obs_data_get_string(s, "stream_start_path")
    cfg.stream_stop_path  = o.obs_data_get_string(s, "stream_stop_path")
    cfg.volume            = o.obs_data_get_int(s,    "volume")
end
